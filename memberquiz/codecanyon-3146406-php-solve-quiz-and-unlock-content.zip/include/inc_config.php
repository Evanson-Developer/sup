<?php
/***************** set BACK-END path (starting from WEBSITE root) ***************/
$sfw_path = '';

/***************** set IMAGE path for BACK-END (starting from BACK-END root) ***************/
$path_img_back = 'img'; // IMPORTANT : NO SLASH AT START AND AT THE END 

/***************** set path where some quizzes' file will be store (with WRITE and READ permissions) (starting from WEBSITE root) ***************/
 // IMPORTANT : NO SLASH AT START AND AT THE END 
$path_stored_quizzes = '';

/***************** Site administration email ***************/
$admin_email = '';

/***************** Date format ***************/
$date_format = 'dd/mm/yyyy'; // "mm/dd/yyyy", "dd/mm/yyyy"

/***************** set parameters for database connection ***************/
/* host name */
$hostname = '';
/* database userid */
$username = '';
/* database password */
$password = '';
/* database name */
$db = '';
?>